package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Util.Conexion;

public class Usuario {

	    private int id;
	    private String nombres;
	    private String apellidos;
	    private String correo;
	    private String password;

	    
	    public Usuario() {
		}


		public Usuario(int id, String nombres, String apellidos, String correo, String password) {
	        this.id = id;
	        this.nombres = nombres;
	        this.apellidos = apellidos;
	        this.correo = correo;
	        this.password = password;
	    }


		public int getId() {
			return id;
		}


		public void setId(int id) {
			this.id = id;
		}


		public String getNombres() {
			return nombres;
		}


		public void setNombres(String nombres) {
			this.nombres = nombres;
		}


		public String getApellidos() {
			return apellidos;
		}


		public void setApellidos(String apellidos) {
			this.apellidos = apellidos;
		}


		public String getCorreo() {
			return correo;
		}


		public void setCorreo(String correo) {
			this.correo = correo;
		}


		public String getPassword() {
			return password;
		}


		public void setPassword(String password) {
			this.password = password;
		}
		
		public void consultarUsuarios() {
		    Conexion conexion = new Conexion(); 

		    try {
		        Statement stmt = conexion.con.createStatement();
		        ResultSet rs = stmt.executeQuery("SELECT * FROM Usuario");

		        while (rs.next()) {
		            int id = rs.getInt("id");
		            String email = rs.getString("email");
		            String password = rs.getString("password");

		            
		        }

		        conexion.con.close();
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		}
		
		public void guardarUsuario(Usuario usuario) {
		    Conexion conexion = new Conexion(); 

		    try {
		        // Usar PreparedStatement para evitar SQL injection
		        String query = "INSERT INTO Usuario (id, email, password, nombres, apellidos) VALUES (?, ?, ?, ?, ?)";
		        PreparedStatement pstmt = conexion.con.prepareStatement(query);
		        
		        // Establecer los valores en la consulta
		        pstmt.setInt(1, usuario.getId());
		        pstmt.setString(2, usuario.getCorreo());
		        pstmt.setString(3, usuario.getPassword());
		        pstmt.setString(4, usuario.getNombres());
		        pstmt.setString(5, usuario.getApellidos());

		        // Ejecutar la actualización
		        int filasInsertadas = pstmt.executeUpdate();
		        
		        // Comprobar si se insertó correctamente
		        if (filasInsertadas > 0) {
		            
		        }

		        // Cerrar la conexión
		        conexion.con.close();
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		}


}
	    
	


