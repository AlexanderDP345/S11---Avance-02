package View;

import javax.swing.JPanel;

import Core.Model;
import Core.View;

public class SolicitarAsistenciaLegalView extends JPanel  implements View {

	@Override
	public void update(Model model, Object data) {
		
		
	}

}
