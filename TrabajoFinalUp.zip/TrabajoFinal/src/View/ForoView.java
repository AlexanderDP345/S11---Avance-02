package View;

import javax.swing.JPanel;

import Core.Model;
import Core.View;

public class ForoView extends JPanel implements View{

	@Override
	public void update(Model model, Object data) {
		// TODO Auto-generated method stub
		
	}

}
