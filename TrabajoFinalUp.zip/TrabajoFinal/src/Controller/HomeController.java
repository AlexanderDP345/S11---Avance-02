package Controller;


import Core.Controller;
import View.ForoView;
import View.HomeView;
import View.MenuPrincipalView;
import View.RealizarDenunciaView;
import View.SolicitarAsistenciaLegalView;


public class HomeController extends Controller{
	
	private HomeView homeView;
	private MenuPrincipalController MenuPrincipalController = new MenuPrincipalController();
	private RealizarDenunciaController RealizarDenunciaController = new RealizarDenunciaController();
	private SolicitarAsistenciaLegalController SolicitarAsistenciaLegalController = new SolicitarAsistenciaLegalController();
	private ForoController ForoController = new ForoController();
	
	@Override
	public void run() {
		// Initializes others controllers
					MenuPrincipalController.run();
					RealizarDenunciaController.run();
					SolicitarAsistenciaLegalController.run();
					ForoController.run();
					
					
					
					// Initializes HomeView
					homeView = new HomeView(this, mainFrame);
					addView("HomeView", homeView);
					
					// Displays the program window
					mainFrame.setVisible(true);
		
	}
	
	public MenuPrincipalView getMenuPrincipalView()
	{
		return MenuPrincipalController.getView();
	}
	
	public RealizarDenunciaView getRealizarDenunciaView()
	{
		return RealizarDenunciaController.getView();
	}
	
	public SolicitarAsistenciaLegalView getSolicitarAsistenciaLegalView()
	{
		return SolicitarAsistenciaLegalController.getView();
	}
	
	public ForoView getForoView()
	{
		return ForoController.getView();
	}
	


}
