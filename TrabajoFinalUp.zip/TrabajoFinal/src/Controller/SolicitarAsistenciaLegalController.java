package Controller;

import Core.Controller;
import View.SolicitarAsistenciaLegalView;


public class SolicitarAsistenciaLegalController extends Controller{
	
	private SolicitarAsistenciaLegalView SolicitarAsistenciaLegalView;

	@Override
	public void run() {
		SolicitarAsistenciaLegalView =new SolicitarAsistenciaLegalView();
		
	}
	
	public SolicitarAsistenciaLegalView getView() {
		return SolicitarAsistenciaLegalView;
	}

}
