package Controller;

import Core.Controller;
import View.MenuPrincipalView;


public class MenuPrincipalController extends Controller {

	
	private MenuPrincipalView MenuPrincipalView;

	@Override
	public void run() {
		MenuPrincipalView = new MenuPrincipalView(this);
		
	}

	public MenuPrincipalView getView() {
		return MenuPrincipalView;
	}

}
