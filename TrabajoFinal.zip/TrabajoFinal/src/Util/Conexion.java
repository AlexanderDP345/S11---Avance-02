package Util;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {

	private String driver="com.mysql.jdbc.Driver";
	private String cadenaConeccion="jdbc:mysql://127.0.0.1/TrabajoFinal";
	private String user="root";
	
	public Connection con;
	
	public Conexion() {
	    String password = ""; 
	    try {
	        Class.forName(driver);
	        con = DriverManager.getConnection(cadenaConeccion, user, password);
	        System.out.println("¡Conexión exitosa a la base de datos!");
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

}




	
	
	


