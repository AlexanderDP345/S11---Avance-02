package View;

import javax.swing.JPanel;
import javax.swing.ImageIcon;
import Controller.MenuPrincipalController;
import Core.Model;
import Core.View;
import javax.swing.JLabel;
import java.awt.Font;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;

import javax.swing.JButton;

import java.awt.Color;


public class MenuPrincipalView extends JPanel implements View {

	
	
	public MenuPrincipalView(MenuPrincipalController menuPrincipalController) 
	{
		
		make_frame();
		make_field_titulo();
		make_field_subtitulo();
		make_field_descripcion();
		make_btn_cerrarsesion();
	}


	private void make_frame() { setLayout(null); }
	
	private void make_field_titulo() {
	    JPanel panelTitulo = new JPanel();
	    panelTitulo.setBounds(77, 17, 299, 52);
	    panelTitulo.setLayout(null); // Agregamos este layout null para posicionar manualmente los componentes dentro del JPanel
	    add(panelTitulo);

	    JLabel lblTitulo = new JLabel("Girl Peace");
	    lblTitulo.setForeground(new Color(102, 102, 204));
	    lblTitulo.setFont(new Font("Lao MN", Font.BOLD | Font.ITALIC, 18));
	    lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
	    lblTitulo.setBounds(69, -11, 163, 84); // Ajustamos los bounds del JLabel dentro del JPanel
	    panelTitulo.add(lblTitulo);

	    ImageIcon iconoPaloma = new ImageIcon("/Applications/paloma.png");

	    JButton btnPaloma = new JButton(iconoPaloma);
	    btnPaloma.setBounds(210, 0, 52, 52); // Posicionamos el botón de la paloma al lado derecho del JLabel
	    btnPaloma.setContentAreaFilled(false);
	    btnPaloma.setBorderPainted(false);

	    panelTitulo.add(btnPaloma);
	}

	private void make_field_subtitulo() {
		JLabel lblSubtitulo = new JLabel("¡Bienvenida!");
		lblSubtitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblSubtitulo.setBounds(161, 79, 132, 16);
		add(lblSubtitulo);
	}
		

	private void make_field_descripcion() {
		 
		 JLabel lblDescripcionyFunc = new JLabel("Guía de nuestro lugar seguro:");
		 lblDescripcionyFunc.setFont(new Font("Lucida Grande", Font.BOLD, 12));
		 lblDescripcionyFunc.setHorizontalAlignment(SwingConstants.CENTER);
		 lblDescripcionyFunc.setBounds(120, 95, 201, 32);
		 add(lblDescripcionyFunc);
		 
		 JLabel lblDescripcion = new JLabel("Registra denuncias, solicita asistencia legal y únete a la");
		 	lblDescripcion.setHorizontalAlignment(SwingConstants.CENTER);
		 	lblDescripcion.setToolTipText("");
		 	lblDescripcion.setVerticalAlignment(SwingConstants.TOP);
		 	lblDescripcion.setBounds(45, 139, 368, 29);
		 	add(lblDescripcion);
		
		 	JLabel lblDescripcion2 = new JLabel("comunidad para crear un futuro más seguro.");
		 	lblDescripcion2.setHorizontalAlignment(SwingConstants.CENTER);
		 	lblDescripcion2.setBounds(57, 162, 356, 32);
		 	add(lblDescripcion2);
		 
		 	JLabel lblDescripcion3 = new JLabel("¡Toma acción ahora!");
		 	lblDescripcion3.setHorizontalAlignment(SwingConstants.CENTER);
		 	lblDescripcion3.setBounds(45, 190, 356, 32);
		 	add(lblDescripcion3);
		 
		
	}



	private void make_btn_cerrarsesion() {
	 
	 JButton btnCerrarSesion = new JButton("Cerrar Sesión");
	 btnCerrarSesion.setBounds(165, 234, 117, 29);
	 add(btnCerrarSesion);
	 
	// Add action listener
		btnCerrarSesion.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
	}

	 
	
	@Override
	public void update(Model model, Object data) {
		
		
	}
}
