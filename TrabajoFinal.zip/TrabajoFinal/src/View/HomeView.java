package View;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.border.EmptyBorder;

import Controller.HomeController;
import Core.Model;
import Core.View;

public class HomeView extends JPanel implements View {

    private HomeController homeController;
    private JFrame mainFrame;
    private JTabbedPane tabbedPane;
    private final static int MAIN_FRAME_WIDTH = 500;
    private final static int MAIN_FRAME_HEIGHT = 350;
    private final static int MAIN_FRAME_X = 100;
    private final static int MAIN_FRAME_Y = 100;

    public HomeView(HomeController homeController, JFrame mainFrame) {
        this.homeController = homeController;
        this.mainFrame = mainFrame;
        makeMainFrame();
        makeTabs();
    }

    private void makeMainFrame() {
        mainFrame.setOpacity(1.0f);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setBounds(MAIN_FRAME_X, MAIN_FRAME_Y, MAIN_FRAME_WIDTH, MAIN_FRAME_HEIGHT);
        mainFrame.setMinimumSize(new Dimension(MAIN_FRAME_WIDTH, MAIN_FRAME_HEIGHT));

        setBorder(new EmptyBorder(5, 5, 5, 5));
        setLayout(new BorderLayout(0, 0));
    }

    private void makeTabs() {
    	JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.addTab("Menú Principal", homeController.getMenuPrincipalView());
		tabbedPane.addTab("Realizar Denuncia", homeController.getRealizarDenunciaView());
		tabbedPane.addTab("Solicitar Asistencia Legal", homeController.getSolicitarAsistenciaLegalView());
		tabbedPane.addTab("Foros", homeController.getForoView());
		add(tabbedPane, BorderLayout.CENTER);
    }

 

	@Override
	public void update(Model model, Object data) {
		// TODO Auto-generated method stub
		
	}
}
