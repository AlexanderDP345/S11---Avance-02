package View;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;


public class SignupView extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextArea txtNombre;
    private JTextArea txtApellido;
    private JTextArea txtUsername;
    private JPasswordField txtPassword;
    private JButton btnSignup;
	

    public SignupView() {
    	
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        iniciarComponentes();
  
    }

    private void iniciarComponentes() {
        contentPane.setLayout(null);

        JLabel lblnombre = new JLabel("Ingrese sus nombres:");
        lblnombre.setBounds(67, 38, 165, 16);
        getContentPane().add(lblnombre);

        txtNombre = new JTextArea();
        txtNombre.setBounds(67, 58, 302, 16);
        getContentPane().add(txtNombre);

        JLabel lblApellidos = new JLabel("Ingrese sus apellidos:");
        lblApellidos.setBounds(67, 82, 186, 16);
        contentPane.add(lblApellidos);

        txtApellido = new JTextArea();
        txtApellido.setBounds(67, 100, 306, 17);
        contentPane.add(txtApellido);

        JLabel lblusername = new JLabel("Ingrese su correo electrónico:");
        lblusername.setBounds(67, 126, 231, 16);
        getContentPane().add(lblusername);

        txtUsername = new JTextArea();
        txtUsername.setBounds(67, 149, 302, 16);
        getContentPane().add(txtUsername);

        ((AbstractDocument) txtUsername.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                String newText = fb.getDocument().getText(0, fb.getDocument().getLength()) + text;
                if (newText.length() <= 20) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });

        JLabel lblPassword = new JLabel("Ingrese una contraseña segura:");
        lblPassword.setBounds(67, 177, 209, 16);
        getContentPane().add(lblPassword);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(59, 192, 317, 26);
        getContentPane().add(txtPassword);

        ((AbstractDocument) txtPassword.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                String newText = fb.getDocument().getText(0, fb.getDocument().getLength()) + text;
                if (newText.length() <= 15) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });

        JLabel lblSignup = new JLabel("Sign up");
        lblSignup.setHorizontalAlignment(SwingConstants.CENTER);
        lblSignup.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 18));
        lblSignup.setBounds(144, 0, 132, 46);
        getContentPane().add(lblSignup);

        btnSignup = new JButton("Sign up");
        btnSignup.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
        btnSignup.setBounds(155, 230, 121, 37);
        btnSignup.addActionListener(this);
        getContentPane().add(btnSignup);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnSignup) {
            String nombres = txtNombre.getText().trim();
            String apellidos = txtApellido.getText().trim();
            String username = txtUsername.getText().trim();
            String password = new String(txtPassword.getPassword()).trim();
            
            if (nombres.isEmpty() || apellidos.isEmpty() || username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Ha sido registrado exitosamente");
              
            }

            
            LoginView loginView = new LoginView();
            loginView.setVisible(true);
            this.dispose();
        }
    }
}
