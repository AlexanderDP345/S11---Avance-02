package View;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import Controller.HomeController;
import Core.Controller;

public class LoginView extends JFrame implements ActionListener {

    private HomeView homeView;
    private HomeController homeController;
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextArea txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private JButton btnSignup;
    private SignupView signupWindow;

    public static void main(String[] args) {
    	
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    LoginView frame = new LoginView();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public LoginView() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        homeController = new HomeController();
        iniciarComponentes();
    }

    private void iniciarComponentes() {
        contentPane.setLayout(null);

        JLabel lblusername = new JLabel("Correo Electrónico:");
        lblusername.setBounds(84, 49, 162, 16);
        getContentPane().add(lblusername);

        txtUsername = new JTextArea();
        txtUsername.setBounds(84, 77, 258, 16);
        getContentPane().add(txtUsername);

        ((AbstractDocument) txtUsername.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                String newText = fb.getDocument().getText(0, fb.getDocument().getLength()) + text;
                if (newText.length() <= 20) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });

        JLabel lblPassword = new JLabel("Contraseña:");
        lblPassword.setBounds(84, 128, 162, 16);
        getContentPane().add(lblPassword);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(84, 156, 258, 26);
        getContentPane().add(txtPassword);

        ((AbstractDocument) txtPassword.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                String newText = fb.getDocument().getText(0, fb.getDocument().getLength()) + text;
                if (newText.length() <= 15) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });

        JLabel lblLogin = new JLabel("Log in");
        lblLogin.setHorizontalAlignment(SwingConstants.CENTER);
        lblLogin.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 28));
        lblLogin.setBounds(159, 3, 109, 34);
        getContentPane().add(lblLogin);

        btnLogin = new JButton("Log in");
        btnLogin.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
        btnLogin.setBounds(171, 194, 97, 33);
        btnLogin.addActionListener(this);
        getContentPane().add(btnLogin);

        JLabel lblSignup = new JLabel("¿No tienes una cuenta?");
        lblSignup.setBounds(101, 239, 145, 16);
        getContentPane().add(lblSignup);

        btnSignup = new JButton("Sign up");
        btnSignup.setBounds(251, 234, 91, 29);
        getContentPane().add(btnSignup);
        btnSignup.addActionListener(this);
        signupWindow = new SignupView();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnLogin) {
            String username = txtUsername.getText().trim();
            String password = new String(txtPassword.getPassword()).trim();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                boolean autenticado = autenticarUsuario(username, password);

                if (autenticado) {
                    JOptionPane.showMessageDialog(this, "Cliente autenticado", "Autenticación Exitosa", JOptionPane.INFORMATION_MESSAGE);
                    
                    this.dispose(); // Cierra la ventana de login
                    abrirMenuPrincipal();
                    
                } else {
                    JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else if (e.getSource() == btnSignup) {
            if (signupWindow == null) {
                signupWindow = new SignupView();
            }
            signupWindow.setVisible(true);
        }
    }

    private boolean autenticarUsuario(String username, String password) {
        // Simulación de la lógica de autenticación. Aquí puedes implementar la lógica real.
        return username.equals("test") && password.equals("1234");
    }
    
    public void abrirMenuPrincipal() {

    	Controller c = new HomeController();
		c.run();
    }

}
