package View;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import Controller.RealizarDenunciaController;
import Core.Model;
import Core.View;

public class RealizarDenunciaView extends JPanel implements View {
	
	 private JTable table;
	 private JTextField tf_buscar;
	 private RealizarDenunciaController realizarDenunciaController;
	 
	 
	 public RealizarDenunciaView(RealizarDenunciaController realizarDenunciaController, JTable table) {
	        
	    	this.table = table;
	    	this.realizarDenunciaController = realizarDenunciaController;

	        make_frame();
	        make_btn_buscar();
	        make_field_buscar();
	        make_table();
	        make_btn_denunciar();
	    }


	private void make_frame() { setLayout(null); }

	private void make_btn_buscar() {
		JButton btn_buscar = new JButton("Buscar");
        btn_buscar.setBounds(365, 20, 79, 20);
        add(btn_buscar);

            btn_buscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String palabraClave = tf_buscar.getText().trim();
                Vector<Vector<Object>> resultados = realizarDenunciaController.buscarEvento(palabraClave);
                realizarDenunciaController.actualizarTablaConResultados(resultados);
            }
        });
    }

	private void make_field_buscar() {
		JLabel lbl_denuncia = new JLabel("Buscar denuncia:");
        lbl_denuncia.setFont(new Font("Tahoma", Font.BOLD, 11));
        lbl_denuncia.setBounds(29, 20, 117, 20);
        add(lbl_denuncia);

        tf_buscar = new JTextField();
        tf_buscar.setBounds(133, 20, 217, 20);
        add(tf_buscar);
		
	}

	private void make_table() {
		JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(6, 52, 438, 179); 
        add(scrollPane);
		
	}
	
	  private void make_btn_denunciar() {
	        JButton btnDenunciar = new JButton("Denunciar");
	        btnDenunciar.setBounds(181, 232, 100, 30); 
	        add(btnDenunciar);

	        btnDenunciar.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                DenunciaView denunciaView = new DenunciaView();
	                denunciaView.setVisible(true);
	            }
	        });
	    }

	@Override
	public void update(Model model, Object data) {
		if (data != null) {
			String notice = (String) data;
			JOptionPane.showMessageDialog(null, notice);
		}
		
	}

}
