package Controller;

import java.util.Vector;

import javax.swing.JTable;

import Core.Controller;
import View.RealizarDenunciaView;

public class RealizarDenunciaController extends Controller  {

	private RealizarDenunciaView RealizarDenunciaView;
	private JTable table;
	private Vector<Vector<Object>> denunciaList;
	

	@Override
	public void run() {
		
		table = new JTable(getDataColumns(), getNameColumns());
		RealizarDenunciaView = new RealizarDenunciaView(this, table);
		denunciaList = getDataColumns();
	
		
	}
	
	public RealizarDenunciaView getView() {
		return RealizarDenunciaView;
	}

	public void actualizarTablaConResultados(Vector<Vector<Object>> resultados) {
		// TODO Auto-generated method stub
		
	}

	public Vector<Vector<Object>> buscarEvento(String palabraClave) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public Vector<String> getNameColumns() 
	{
		Vector<String> nameColumns = new Vector<String>();
		
		nameColumns.add("Distrito");
		nameColumns.add("Tipo de Denuncia");
		nameColumns.add("Descripción de la Denuncia");
		
		
		return nameColumns;
	}
	
	public Vector<Vector<Object>> getDataColumns() 
	{
		return null;
		
	}

}
