package Controller;

import Core.Controller;
import View.SolicitarAsistenciaLegalView;

public class AsistenciaLegalController extends Controller {

	private SolicitarAsistenciaLegalView AsistenciaLegalView;

	@Override
	public void run() {
		AsistenciaLegalView = new SolicitarAsistenciaLegalView();
		
	}

}
