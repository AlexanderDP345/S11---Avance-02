package Controller;

import Core.Controller;
import View.ForoView;

public class ForoController extends Controller {

	private ForoView ForoView;

	@Override
	public void run() {
		ForoView =new ForoView();
		
	}
	
	public ForoView getView() {
		return ForoView;
	}

}
