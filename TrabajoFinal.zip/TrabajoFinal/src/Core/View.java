package Core;

import Core.Model;

public interface View {
	public void update(Model model, Object data);
	
}
